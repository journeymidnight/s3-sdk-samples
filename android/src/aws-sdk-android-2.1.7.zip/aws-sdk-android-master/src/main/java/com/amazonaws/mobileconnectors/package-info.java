/**
 * The mobileconnectors package includes higher level classes that make accessing AWS services from a mobile device more convenient.
 */

package com.amazonaws.mobileconnectors;
