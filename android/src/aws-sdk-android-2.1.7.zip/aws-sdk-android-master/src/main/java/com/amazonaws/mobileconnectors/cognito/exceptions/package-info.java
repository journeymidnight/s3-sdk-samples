/**
 * Cognito mobile connector related exception classes.
 */

package com.amazonaws.mobileconnectors.cognito.exceptions;

