/**
 * S3 Transfer Manager connector related exception classes
 */

package com.amazonaws.mobileconnectors.s3.transfermanager.exception;
