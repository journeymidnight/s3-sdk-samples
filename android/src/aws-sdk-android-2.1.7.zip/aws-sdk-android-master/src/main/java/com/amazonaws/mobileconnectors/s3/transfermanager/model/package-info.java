/**
 * S3 Transfer Manager connector related model classes
 */

package com.amazonaws.mobileconnectors.s3.transfermanager.model;
