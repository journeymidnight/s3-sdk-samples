/**
 * Primary classes for interacting with the S3 Transfer Manager connector which simplifies uploading and downloading files from S3.
 */
package com.amazonaws.mobileconnectors.s3.transfermanager;
