package com.example.s3_test;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.*;

import java.io.File;
import java.io.FileOutputStream;

public class MyActivity extends Activity {
    private static AmazonS3Client sS3Client;
    private static final int PHOTO_SELECTED = 1;
    private static final int PHOTO_Download = 2;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        sS3Client = new AmazonS3Client(
                new BasicAWSCredentials(Constants.ACCESS_KEY_ID, Constants.SECRET_KEY));
        sS3Client.setEndpoint(Constants.S3_ENDPOINT);




        //下载
        findViewById(R.id.btn_dnld).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                String downloadPath = Environment.getExternalStorageDirectory().getPath() + "/download_cache";
                GetObjectRequest request = new GetObjectRequest(
                        Constants.BUCKET_NAME, "imageFilename");

                File dnFile=new File(downloadPath + "/imagefile.jpg");
                sS3Client.getObject(request,dnFile);
               FileType.OpenFile(MyActivity.this,dnFile);
            }
        });




        //上传
        findViewById(R.id.btn_upld).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent, PHOTO_SELECTED);

            }
        });

    }



    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);

        switch (requestCode) {
            case PHOTO_SELECTED:
                if (resultCode == RESULT_OK) {

                    Uri selectedImage = imageReturnedIntent.getData();
                    new S3PutObjectTask().execute(selectedImage);
                }
        }
    }

    private class S3PutObjectTask extends AsyncTask<Uri, Void, S3TaskResult> {

        ProgressDialog dialog;

        protected void onPreExecute() {
            dialog = new ProgressDialog(MyActivity.this);
            dialog.setMessage("uploading...");
            dialog.setCancelable(false);
            dialog.show();
        }

        protected S3TaskResult doInBackground(Uri... uris) {

            if (uris == null || uris.length != 1) {
                return null;
            }


            Uri selectedImage = uris[0];


            ContentResolver resolver = getContentResolver();
            String fileSizeColumn[] = {OpenableColumns.SIZE};

            Cursor cursor = resolver.query(selectedImage,
                    fileSizeColumn, null, null, null);

            cursor.moveToFirst();

            int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
            String size = null;
            if (!cursor.isNull(sizeIndex)) {
                size = cursor.getString(sizeIndex);
            }

            cursor.close();

            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentType(resolver.getType(selectedImage));
            if(size != null){
                metadata.setContentLength(Long.parseLong(size));
            }

            S3TaskResult result = new S3TaskResult();

            // 上传图像文件
            try {
                //  //设置bucket acl
              //  sS3Client.createBucket(Constants.BUCKET_NAME);

                 sS3Client.createBucket(new CreateBucketRequest(Constants.BUCKET_NAME)
                         .withCannedAcl(CannedAccessControlList.PublicRead));

                PutObjectRequest por = new PutObjectRequest(
                        Constants.BUCKET_NAME, "imageFilename",
                        resolver.openInputStream(selectedImage),metadata);
                sS3Client.putObject(por);

            } catch (Exception exception) {

                result.setErrorMessage(exception.getMessage());
            }

            return result;
        }

        protected void onPostExecute(S3TaskResult result) {

            dialog.dismiss();

            if (result.getErrorMessage() != null) {
                displayErrorAlert("upload failure!!!",
                        result.getErrorMessage());
            }
        }
    }

    protected void displayErrorAlert(String title, String message) {

        AlertDialog.Builder confirm = new AlertDialog.Builder(this);
        confirm.setTitle(title);
        confirm.setMessage(message);

        confirm.setNegativeButton(
                "upload ok!!!",
                new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {

                        MyActivity.this.finish();
                    }
                });

        confirm.show().show();
    }



    private class S3TaskResult {
        String errorMessage = null;
        Uri uri = null;

        public String getErrorMessage() {
            return errorMessage;
        }

        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }

        public Uri getUri() {
            return uri;
        }

        public void setUri(Uri uri) {
            this.uri = uri;
        }
    }

}
