
package com.example.s3_test;

import java.util.Locale;

public class Constants {
//
//    public static final String ACCESS_KEY_ID = "9EEIWGS705M4ZJ3N7FEM";
//    public static final String SECRET_KEY = "8humW3nOraybmbIjY6s15IVned87gz/nUrgxYlEX";
//    public static final String BUCKET_NAME = "my-first-s3-bucket";
//    public static final String S3_ENDPOINT ="http://s3.lecloud.com";

    public static final String ACCESS_KEY_ID = "2X9NGJZN0E74HE2W9KB6";
    public static final String SECRET_KEY = "2l+854/rdcF+7zdnuKw5o3oFpWknlv9Oj6LN3ZIK";
    public static final String BUCKET_NAME = "huang2";
    public static final String S3_ENDPOINT ="http://s3.lecloud.com";

}
