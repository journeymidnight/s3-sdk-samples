
package com.example.s3_test;

import java.util.Locale;

public class Constants {

    public static final String ACCESS_KEY_ID = "9EEIWGS705M4ZJ3N7FEM";
    public static final String SECRET_KEY = "8humW3nOraybmbIjY6s15IVned87gz/nUrgxYlEX";
    public static final String BUCKET_NAME = "my-first-s3-bucket";
    public static final String S3_ENDPOINT ="http://s3.lecloud.com";



}
